var nome = "João";
var sobrenome = "Silva";

document.getElementById("nome").innerHTML = nome;
document.getElementById("sobrenome").innerHTML = sobrenome;


document.write("ESTE É UM ERRO PROPOSITAL. ")